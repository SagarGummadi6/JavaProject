import java.util.*;

public class Library {
    private final List<Book> books = new ArrayList<>();
    private final Map<String, Date> borrowedBooks = new HashMap<>();
    private static final int BORROW_DAYS = 14;
    private static final double LATE_FEE_PER_DAY = 1.0;

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Added: " + book.getTitle());
    }

    public void removeBook(String bookId) {
        boolean removed = false;
        for (Book book : books) {
            if (book.getId().equalsIgnoreCase(bookId)) {
                books.remove(book);
                removed = true;
                break;
            }
        }
        System.out.println(removed ? "Book removed!" : "Book not found!");
    }

    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available.");
            return;
        }
        System.out.println("\nLIBRARY CATALOG:");
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public List<String> getAllCategories() {
        List<String> categories = new ArrayList<>();
        for (Book book : books) {
            String category = book.getCategory();
            if (!categories.contains(category)) {
                categories.add(category);
            }
        }
        return categories;
    }

    public void displayCategories() {
        List<String> categories = getAllCategories();
        if (categories.isEmpty()) {
            System.out.println("No categories available.");
            return;
        }
        System.out.println("\nAVAILABLE CATEGORIES:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i));
        }
    }

    public void searchByCategory(String category) {
        System.out.println("\nBOOKS IN '" + category.toUpperCase() + "':");
        boolean found = false;
        for (Book book : books) {
            if (book.getCategory().equalsIgnoreCase(category)) {
                System.out.println(book);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found in this category.");
        }
    }

    public void borrowBook(String bookId, String username) {
        for (Book book : books) {
            if (book.getId().equalsIgnoreCase(bookId)) {
                if (!book.isAvailable()) {
                    System.out.println("Book already borrowed!");
                    return;
                }
                book.setAvailable(false);
                Calendar dueDate = Calendar.getInstance();
                dueDate.add(Calendar.DAY_OF_MONTH, BORROW_DAYS);
                borrowedBooks.put(bookId.toLowerCase(), dueDate.getTime());
                System.out.printf("%s borrowed by %s. Due: %tD%n",
                        book.getTitle(), username, dueDate);
                return;
            }
        }
        System.out.println("Book not found!");
    }

    public void returnBook(String bookId) {
        Date dueDate = borrowedBooks.remove(bookId.toLowerCase());
        if (dueDate == null) {
            System.out.println("This book wasn't borrowed from here!");
            return;
        }

        for (Book book : books) {
            if (book.getId().equalsIgnoreCase(bookId)) {
                book.setAvailable(true);
                break;
            }
        }

        long daysLate = (new Date().getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24);
        if (daysLate > 0) {
            System.out.printf("Late by %d days. Fine: $%.2f%n", daysLate, daysLate * LATE_FEE_PER_DAY);
        } else {
            System.out.println("Returned on time. Thank you!");
        }
    }

    public void displayBorrowedBooks() {
        System.out.println("\nBORROWED BOOKS:");
        if (borrowedBooks.isEmpty()) {
            System.out.println("No books currently borrowed.");
            return;
        }

        for (Map.Entry<String, Date> entry : borrowedBooks.entrySet()) {
            String bookId = entry.getKey();
            Date dueDate = entry.getValue();
            for (Book book : books) {
                if (book.getId().equalsIgnoreCase(bookId)) {
                    System.out.printf("%s (Due: %tD)%n", book, dueDate);
                    break;
                }
            }
        }
    }
}
