import java.util.Scanner;
public class Librarian extends User {
    private final Library library;

    public Librarian(String username, Library library) {
        super(username);
        this.library = library;
    }

    @Override
    public void showMenu() {
        System.out.println("\nLIBRARIAN MENU:");
        System.out.println("1. View all books");
        System.out.println("2. Add a new book");
        System.out.println("3. Remove a book");
        System.out.println("4. View borrowed books");
        System.out.println("5. Exit");
    }

    @Override
    public void handleUserChoice(int choice, Scanner scanner) {
        switch (choice) {
            case 1 : library.displayAllBooks();
            case 2 : addNewBook(scanner);
            case 3 : {
                System.out.print("Enter book ID to remove: ");
                library.removeBook(scanner.nextLine());
            }
            case 4 : library.displayBorrowedBooks();
            case 5 : System.out.println("Logging out...");
            default : System.out.println("Invalid choice!");
        }
    }

    private void addNewBook(Scanner scanner) {
        System.out.print("Enter book ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter category: ");
        String category = scanner.nextLine();
        library.addBook(new Book(id, title, author, category));
    }
}