import java.util.Scanner;
public class Member extends User {
    private final Library library;

    public Member(String username, Library library) {
        super(username);
        this.library = library;
    }

    @Override
    public void showMenu() {
        System.out.println("\nMEMBER MENU:");
        System.out.println("1. View all books");
        System.out.println("2. Search by category");
        System.out.println("3. Borrow a book");
        System.out.println("4. Return a book");
        System.out.println("5. Exit");
    }

    @Override
    public void handleUserChoice(int choice, Scanner scanner) {
        switch (choice) {
            case 1 : library.displayAllBooks();
            case 2 : {
                library.displayCategories();
                System.out.print("Enter category name: ");
                library.searchByCategory(scanner.nextLine());
            }
            case 3 : {
                System.out.print("Enter book ID to borrow: ");
                library.borrowBook(scanner.nextLine(), username);
            }
            case 4 : {
                System.out.print("Enter book ID to return: ");
                library.returnBook(scanner.nextLine());
            }
            case 5 : System.out.println("Logging out...");
            default : System.out.println("Invalid choice!");
        }
    }
}