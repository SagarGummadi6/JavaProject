import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();


        library.addBook(new Book("FIC-001", "The Hobbit", "J.R.R. Tolkien", "Fantasy"));
        library.addBook(new Book("SCI-001", "Cosmos", "Carl Sagan", "Science"));

        System.out.println("=== LIBRARY MANAGEMENT SYSTEM ===");
        System.out.print("Enter your name: ");
        String username = scanner.nextLine();

        User user = getUserRole(scanner, username, library);

        boolean running = true;
        while (running) {
            user.showMenu();
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            user.handleUserChoice(choice, scanner);
            if (choice == 5) running = false;
        }

        System.out.println("Goodbye, " + username + "!");
        scanner.close();
    }

    private static User getUserRole(Scanner scanner, String username, Library library) {
        while (true) {
            System.out.print("Are you a (M)ember or (L)ibrarian? ");
            String role = scanner.nextLine().trim().toLowerCase();

            if (role.startsWith("m")) return new Member(username, library);
            if (role.startsWith("l")) return new Librarian(username, library);

            System.out.println("Invalid role! Try again.");
        }
    }
}