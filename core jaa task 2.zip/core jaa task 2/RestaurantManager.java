import java.util.ArrayList;
import java.util.List;

public class RestaurantManager {
    private static final List<Restaurant> restaurants = new ArrayList<>();

    public static void addRestaurant(Restaurant r) {
        restaurants.add(r);
    }

    public static List<Restaurant> getRestaurants() {
        return restaurants;
    }
}