public class Burger extends FoodItem {
    private final boolean isCheese;

    public Burger(String itemId, String name, double price, boolean isCheese) {
        super(itemId, name, price, "Burger");
        this.isCheese = isCheese;
    }

    @Override
    public void displayDetails() {
        System.out.printf("%s Burger - Rs%.2f\n", isCheese ? "Cheese" : "Regular", price);
    }
}