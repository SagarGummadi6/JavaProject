import java.util.List;

public class Order {
    private final String orderId;
    private final String customerId;
    private final String restaurantId;
    private final List<FoodItem> items;
    private String status;

    public Order(String orderId, String customerId, String restaurantId, List<FoodItem> items) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.restaurantId = restaurantId;
        this.items = items;
        this.status = "Preparing";
    }


    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public List<FoodItem> getItems() { return items; }
}