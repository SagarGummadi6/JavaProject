import java.util.List;

public class Salad extends FoodItem {
    private final List<String> ingredients;

    public Salad(String itemId, String name, double price, List<String> ingredients) {
        super(itemId, name, price, "Salad");
        this.ingredients = ingredients;
    }

    @Override
    public void displayDetails() {
        System.out.printf("Salad: %s - Rs%.2f\n", name, price);
        System.out.println("Ingredients: " + String.join(", ", ingredients));
    }
}