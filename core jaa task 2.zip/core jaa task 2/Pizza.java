import java.util.List;

public class Pizza extends FoodItem {
    private final String size;
    private final List<String> toppings;

    public Pizza(String itemId, String name, double price, String size, List<String> toppings) {
        super(itemId, name, price, "Pizza");
        this.size = size;
        this.toppings = toppings;
    }

    @Override
    public void displayDetails() {
        System.out.printf("%s %s Pizza - Rs%.2f\n", size, name, price);
        System.out.println("Toppings: " + String.join(", ", toppings));
    }
}