public abstract class FoodItem {
    protected final String itemId;
    protected final String name;
    protected final double price;
    protected final String category;

    public FoodItem(String itemId, String name, double price, String category) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public abstract void displayDetails();


    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }

}