import java.util.List;

public class Customer implements User {
    private final String userId;
    private final String name;
    private final String address;
    private final Cart cart;

    public Customer(String userId, String name, String address) {
        this.userId = userId;
        this.name = name;
        this.address = address;
        this.cart = new Cart();
    }

    @Override
    public void login() {
        System.out.println("Customer " + name + " logged in (ID: " + userId + ")");
    }

    @Override
    public void register() {
        System.out.println("Customer " + name + " registered successfully.");
    }

    @Override
    public void viewProfile() {
        System.out.println("\nCUSTOMER PROFILE");
        System.out.println("ID: " + userId);
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
    }

    @Override
    public void placeOrder() {
        System.out.println("Placing order... (Handled externally)");
    }

    public void addToCart(FoodItem item) {
        cart.addItem(item);
    }

    public Order checkout(String restaurantId) {
        List<FoodItem> items = cart.checkout();
        return new Order("ORD-" + System.currentTimeMillis(), userId, restaurantId, items);
    }


}