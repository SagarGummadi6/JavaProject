import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Customer customer = new Customer("CUST-1001", "John Doe", "123 Main St");
        customer.register();

        Restaurant restaurant = new Restaurant("REST-2001", "Pizza Palace", "Italian");
        restaurant.register();

        DeliveryDriver driver = new DeliveryDriver("DR-3001", "Mike", "Bike");
        driver.register();

        RestaurantManager.addRestaurant(restaurant);

        restaurant.addMenuItem(new Pizza("PIZZA-001", "Margherita", 399.99, "Medium", Arrays.asList("Tomato", "Cheese")));
        restaurant.addMenuItem(new Burger("BURGER-001", "Paneer Burger", 199.99, true));
        restaurant.addMenuItem(new Salad("SALAD-001", "Greek Salad", 149.99, Arrays.asList("Lettuce", "Feta", "Olives")));

        customer.login();
        customer.viewProfile();
        restaurant.login();
        restaurant.viewProfile();
        driver.login();
        driver.viewProfile();

        System.out.println("\n--- Menu Items ---");
        for (FoodItem item : restaurant.getMenu().getItems()) {
            item.displayDetails();
            System.out.println();
        }

        customer.addToCart(restaurant.getMenu().getItem(0));
        customer.addToCart(restaurant.getMenu().getItem(2));

        customer.placeOrder();
        Order order = customer.checkout(restaurant.getUserId());

        double total = PaymentGateway.calculateTotalAmount(order.getItems());
        PaymentGateway.processPayment(total);

        driver.startDelivery(order);
        driver.trackProgress();
        driver.completeDelivery(order);

        System.out.println("\nFinal Order Status: " + order.getStatus());

        System.out.println("\n--- Registered Restaurants ---");
        for (Restaurant r : RestaurantManager.getRestaurants()) {
            r.viewProfile();
        }
    }
}
