public interface User {
    void login();
    void register();
    void viewProfile();
    void placeOrder();
}