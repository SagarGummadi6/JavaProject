public class Restaurant implements User {
    private final String userId;
    private final String name;
    private final String cuisineType;
    private final Menu menu;

    public Restaurant(String userId, String name, String cuisineType) {
        this.userId = userId;
        this.name = name;
        this.cuisineType = cuisineType;
        this.menu = new Menu();
    }

    @Override
    public void login() {
        System.out.println("Restaurant " + name + " logged in (ID: " + userId + ")");
    }

    @Override
    public void register() {
        System.out.println("Restaurant " + name + " registered successfully.");
    }

    @Override
    public void viewProfile() {
        System.out.println("\nRESTAURANT PROFILE");
        System.out.println("ID: " + userId);
        System.out.println("Name: " + name);
        System.out.println("Cuisine: " + cuisineType);
    }

    @Override
    public void placeOrder() {}

    public void addMenuItem(FoodItem item) {
        menu.addItem(item);
    }

    public Menu getMenu() {
        return menu;
    }

    public String getUserId() {
        return userId;
    }
}