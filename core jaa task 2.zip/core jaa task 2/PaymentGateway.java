import java.util.List;

public class PaymentGateway {
    private static final double TAX_RATE = 0.08;

    public static double calculateTotalAmount(List<FoodItem> items) {
        double subtotal = 0;
        for (FoodItem item : items) {
            subtotal += item.getPrice();
        }
        return subtotal * (1 + TAX_RATE);
    }

    public static boolean processPayment(double amount) {
        System.out.printf("Payment of Rs%.2f processed successfully.\n", amount);
        return true;
    }
}