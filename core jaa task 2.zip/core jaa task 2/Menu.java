import java.util.ArrayList;
import java.util.List;

public class Menu {
    private final List<FoodItem> items = new ArrayList<>();

    public void addItem(FoodItem item) {
        items.add(item);
    }

    public List<FoodItem> getItems() {
        return items;
    }

    public FoodItem getItem(int index) {
        return items.get(index);
    }
}