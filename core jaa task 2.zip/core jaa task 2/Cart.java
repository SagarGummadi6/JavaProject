import java.util.ArrayList;
import java.util.List;

public class Cart {
    private final List<FoodItem> items = new ArrayList<>();

    public void addItem(FoodItem item) {
        items.add(item);
        System.out.println(item.getName() + " added to cart.");
    }

    public List<FoodItem> checkout() {
        List<FoodItem> orderItems = new ArrayList<>(items);
        items.clear();
        return orderItems;
    }
}