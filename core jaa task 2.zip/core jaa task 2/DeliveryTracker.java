public interface DeliveryTracker {
    void startDelivery(Order order);
    void trackProgress();
    void completeDelivery(Order order);
}