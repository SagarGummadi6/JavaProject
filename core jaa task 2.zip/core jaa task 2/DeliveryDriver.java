public class DeliveryDriver implements User, DeliveryTracker {
    private final String userId;
    private final String name;
    private final String vehicleType;

    public DeliveryDriver(String userId, String name, String vehicleType) {
        this.userId = userId;
        this.name = name;
        this.vehicleType = vehicleType;
    }

    @Override
    public void login() {
        System.out.println("Driver " + name + " logged in");
    }

    @Override
    public void register() {
        System.out.println("Driver " + name + " registered successfully.");
    }

    @Override
    public void viewProfile() {
        System.out.println("\nDELIVERY DRIVER PROFILE");
        System.out.println("ID: " + userId);
        System.out.println("Name: " + name);
        System.out.println("Vehicle: " + vehicleType);
    }

    @Override
    public void placeOrder() {}

    @Override
    public void startDelivery(Order order) {
        order.setStatus("On the way");
    }

    @Override
    public void trackProgress() {
        System.out.println("Tracking delivery... Estimated time: 15 mins");
    }

    @Override
    public void completeDelivery(Order order) {
        order.setStatus("Delivered");
    }
}